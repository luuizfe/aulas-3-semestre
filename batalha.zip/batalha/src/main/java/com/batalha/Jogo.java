package com.batalha;

import java.util.List;

public class Jogo {
    
    public List<Jogador> getJogadores(){
        return List.of();
    }

}
