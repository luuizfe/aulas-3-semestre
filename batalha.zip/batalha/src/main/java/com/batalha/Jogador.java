package com.batalha;

import java.util.Random;

public class Jogador {
 private String nome;
 private int xp;
 private int hp;
 private boolean envenenado;
private String classe;
private boolean temAntidoto;

    public String getClasse() {
        return classe;
    }

    public void setClasse(String classe) {
        this.classe = classe;
    }

    public Jogador() {
    }

    public Jogador(String nome) {
        this.nome = nome;
    }

    public int getXp() {
        return xp;
    }

    public int getHp() {
        return hp;
    }

    public boolean isEnvenenado() {
        return envenenado;
    }
    public void receberDano(int pontos){
        hp -= pontos;
    }
    public void receberCura(int pontos){
        hp += pontos;

    }
    public void ganharExperiencia(int pontos){
        xp += pontos;

    }
    public void receberAntidoto(){
        envenenado = false;

    }

    public boolean isTemAntidoto() {
        return temAntidoto;
    }

    public void setTemAntidoto(boolean temAntidoto) {
        this.temAntidoto = temAntidoto;
    }

    public void atacar (Jogador adversario){
        adversario.hp -= this.xp;
        this.xp++;
    }
    public void curar (Jogador curado){
        curado.hp += this.hp+5;

        Random random = new Random();
        if (random.nextInt(100) < 10) {
            curado.temAntidoto = true;

        }
    }
}
