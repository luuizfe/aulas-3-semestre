package com.batalha;

import java.util.List;

public class Jogo {
    private Jogador j1 = new Jogador(Classe.MAGO);
    private Jogador j2 = new Jogador(Classe.GUERREIRO);
    
    public List<Jogador> getJogadores(){
        return List.of(j1, j2);
    }

}
