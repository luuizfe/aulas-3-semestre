package com.batalha;

import java.util.Random;

public class Jogador {
 private String nome;

    public Jogador(Classe classe) {
        this.classe = classe;
    }

    private int xp;
 private int hp;
 private boolean envenenado;
private Classe classe;
private boolean temAntidoto;


    public Classe getClasse() {
        return classe;
    }


    public void receberDano(int pontos){
        hp -= pontos;
    }
    public void receberCura(int pontos){
        hp += pontos;

    }
    public void ganharExperiencia(int pontos){
        xp += pontos;

    }
    public void receberAntidoto(){
        envenenado = false;

    }
    public void darAntidoto(Jogador recebidoAntidoto){

        if(temAntidoto)
    }

    public boolean isTemAntidoto() {
        return temAntidoto;
    }

    public void setTemAntidoto(boolean temAntidoto) {
        this.temAntidoto = temAntidoto;
    }

    public void atacar (Jogador adversario){
        adversario.receberDano(this.xp);
    ganharExperiencia(1);
    }
    public void curar (Jogador curado){
        curado.receberCura(5);

        Random random = new Random();
        if (random.nextInt(100) < 10) {
            curado.temAntidoto = true;

        }
    }
    public void setClasse(Classe classe) {
        this.classe = classe;
    }

    public Jogador() {
    }

    public Jogador(String nome) {
        this.nome = nome;
    }

    public int getXp() {
        return xp;
    }

    public int getHp() {
        return hp;
    }

    public boolean isEnvenenado() {
        return envenenado;
    }
}
