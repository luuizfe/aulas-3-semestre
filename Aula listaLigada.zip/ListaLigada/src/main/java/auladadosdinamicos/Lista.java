package auladadosdinamicos;

import ListaLigada.No;

public class Lista {

    No inicio;

    Lista() {
        this.inicio = null;
    }

    public void inserirLista(No no) {
        if (inicio == null) {
            inicio = no;
        } else {
            No percorre = inicio;
            while (percorre.getProximo() != null) {
                percorre = percorre.getProximo();
            }
            percorre.setProximo(no);
        }

    }

    public void percorreLista() {

        No percorre = inicio;
        while (percorre != null) {
            System.out.println(percorre.getValor());
            percorre = percorre.getProximo();
        }

    }

    public boolean contem(int valor) {
        No escolhido = inicio;
        while (escolhido != null) {
            if (escolhido.getValor() == valor) {
                return true;

            }
            escolhido = escolhido.getProximo();
        }

        return false;
    }

    public void removePrimeiro() {
        if (inicio != null) {
            inicio = inicio.getProximo();

        }
    }

    public void removeUltimo() {
        if (inicio == null) {
            if(inicio.getProximo()==null){
                inicio = null;
                return;
            }
        }
            No percorre = inicio;
            while (percorre.getProximo().getProximo()!=null){
                percorre = percorre.getProximo();
            
        }
            percorre.setProximo(null);

    }
    
    public static void main(String[] args) {
        int exibir = 0;
        No n1 = new No(2);
        No n2 = new No(4);
        No n3 = new No(6);

        Lista l1 = new Lista();

        l1.inserirLista(n1);
        l1.inserirLista(n2);
        l1.inserirLista(n3);

        l1.percorreLista();
        l1.removeUltimo();
        l1.percorreLista();
        //l1.contem(2);

    }
}
