package com.joaocarloslima;

import java.util.ArrayList;
import java.util.List;

public class Maquina {
    private double saldo;
    private double totalArrecadado;
    private List<Refrigerante> refrigerantes = new ArrayList<Refrigerante>();

    public Maquina() {
        for(int i=0;i<10;i++){
            Refrigerante adicionado = new Refrigerante("Coca", 3.50, Sabor.COLA);
            adicionarRefrigerante(adicionado);
        }


    }

    public void adicionarRefrigerante(Refrigerante newRefri){
    refrigerantes.add(newRefri);

    }
    public void inserirDinheiro(double dinheiro) {
        saldo += dinheiro;


    }
    public void sacarDinheiro(){
        saldo=0.0;

    }

    public void comprarRefrigerante(Refrigerante refriEscolhido) {
        if (saldo >= refriEscolhido.getPreco()) {
            refrigerantes.remove(refriEscolhido);
            this.saldo -= refriEscolhido.getPreco();
            this.totalArrecadado += refriEscolhido.getPreco();
        } else {
             throw new RuntimeException("SALDO INSUFICIENTE!!");


        }

    }

    public double getSaldo() {
        return saldo;
    }

    public double getTotalArrecadado() {
        return totalArrecadado;
    }

    public List<Refrigerante> getRefrigerantes() {
        return refrigerantes;
    }



}

