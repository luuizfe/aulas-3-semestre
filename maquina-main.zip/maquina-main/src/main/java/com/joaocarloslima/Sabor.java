package com.joaocarloslima;

public enum Sabor   {
    COLA,
    LARANJA,
    GUARANA,
    UVA,
    LIMAO


}
