/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.javaaplication2;

/**
 *
 * @author guilherme.dviveiros
 */
public class Lista {

    No inicio;

    public Lista() {
        this.inicio = null;
    }

    public void inserirLista(No no) {

        if (inicio == null) {
            inicio = no;
        } else {
            No percorre = inicio;
            while (percorre.getProximo() != null) {
                //System.out.println(percorre.getValor());
                percorre = percorre.getProximo();

            }
            percorre.setProximo(no);
        }
    }

    public void exibeLista() {
        No temp = inicio;
        while (temp!= null) {
            System.out.println(temp.getValor());
            temp = temp.getProximo();

        }

    }
    public void inserirOrdenado(No anterior){
        No escolher = new No(4);
        escolher.proximo = anterior.proximo;
        
        
    }

    public static void main(String[] args) {

        Lista lista1 = new Lista();

        No no1 = new No(1);
        No no2 = new No(4);
        No no3 = new No(5);

        lista1.inserirLista(no1);
        lista1.inserirLista(no2);
        lista1.inserirLista(no3);
        lista1.exibeLista();
        
       
    }

}
